#!/usr/bin/env python3
"""Entry point. Subcommands: features | ablate | aggregate | all"""
import argparse
import os

from invariants import ablation, aggregate, features


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("cmd", choices=["features", "ablate", "aggregate", "all"])
    p.add_argument("--data", default="data", help="folder made by setup_data.sh")
    p.add_argument("--out", default="results")
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--max-sites", type=int, default=3, help="mutants per operator per file")
    p.add_argument("--timeout", type=int, default=15)
    p.add_argument("--limit", type=int, default=None, help="sample N files for ablation (quick test)")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--presence", type=float, default=0.6)
    p.add_argument("--necessity", type=float, default=0.5)
    a = p.parse_args()

    os.makedirs(a.out, exist_ok=True)
    algo = os.path.join(a.data, "TheAlgorithms-Python")
    ros = os.path.join(a.data, "RosettaCodeData")
    alg4 = os.path.join(a.data, "algs4")
    feats = os.path.join(a.out, "features.jsonl")
    abl = os.path.join(a.out, "ablation.jsonl")

    if a.cmd in ("features", "all"):
        features.run(feats, algorithms_py=algo if os.path.isdir(algo) else None,
                     rosetta=ros if os.path.isdir(ros) else None,
                     algs4=alg4 if os.path.isdir(alg4) else None)
    if a.cmd in ("ablate", "all"):
        ablation.run(algo, abl, max_sites=a.max_sites, timeout=a.timeout,
                     workers=a.workers, limit=a.limit, seed=a.seed)
    if a.cmd in ("aggregate", "all"):
        aggregate.aggregate(feats, abl, a.out, t_presence=a.presence, t_necessity=a.necessity)


if __name__ == "__main__":
    main()
