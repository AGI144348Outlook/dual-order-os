# algorithm-invariants

Looks for structural **roles** that working algorithms need, using three corpora:
TheAlgorithms/Python (primary), Rosetta Code Python (replication), Princeton algs4 Java (approximate replication).

The count of invariants is an **output**. Nothing here targets a particular number.

## Instructions for the agent running this (e.g. GPT)

Requirements: Python 3.9+, git, network access to github.com. Standard library only.

```bash
bash setup_data.sh                              # clones the 3 datasets into ./data
python run_all.py features                      # static role extraction (fast, ~1 min)
python run_all.py ablate --limit 150 --workers 4   # quick pass first
python run_all.py aggregate                     # writes results/report.md
```

If the quick pass looks sane, run the full ablation (can take 1-3 hours; it resumes if interrupted):

```bash
python run_all.py ablate --workers 4 --max-sites 3
python run_all.py aggregate
```

Report back: the full contents of `results/report.md` and `results/summary.json`.

Rules for the agent:
- Do not change thresholds, role definitions, or mutation operators to reach a particular count.
- If something breaks, make the smallest fix and say exactly what you changed.
- Run only code from this repo and the cloned datasets; ablation executes doctests from the primary corpus.

## Method

1. **Detect roles** (`invariants/roles.py`): ~26 candidate roles found with Python's `ast` (loop, branch, comparison, accumulate, recursion, base case, swap, guard, return, ...).
2. **Ablate** (`invariants/mutate.py`, `ablation.py`): for each file whose doctests pass, disable or perturb a single occurrence of a role (mutation testing). If tests then fail, that occurrence was necessary.
3. **Aggregate** (`invariants/aggregate.py`): per role, compute presence rate, category coverage, and necessity rate; classify; merge roles that always co-occur (Jaccard >= 0.9); list complementary pairs (roles that substitute for each other, such as loop vs recursion); show a sensitivity grid of the count against thresholds.
4. **Replicate**: check the same roles in Rosetta Code Python and algs4 Java.

## Outputs (`results/`)

- `features.jsonl`: role counts per file per dataset
- `ablation.jsonl`: one line per mutant (killed / survived / invalid)
- `role_table.csv`, `summary.json`, `report.md`

## Known limits

- Roles come from a fixed starting vocabulary; the method cannot discover roles outside it.
- Mutation testing has equivalent mutants, so necessity is a lower bound.
- Only files with passing doctests are ablated, which biases the sample.
- Java detection is regex-based and has no ablation.
- Roles without an ablation operator are reported presence-only.
