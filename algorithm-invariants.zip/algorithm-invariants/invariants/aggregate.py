"""Combine static features + ablation results into an invariants report.

The number of surviving invariants is an OUTPUT of this step. Thresholds are
parameters, and a sensitivity grid shows how the count moves with them.
"""
import csv
import json
import math
import os
from collections import defaultdict

from .mutate import ROLES_WITH_ABLATION
from .roles import ROLES

PRIMARY = "algorithms_py"


def _load(path):
    if not path or not os.path.exists(path):
        return []
    rows = []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if line:
                try:
                    rows.append(json.loads(line))
                except Exception:
                    pass
    return rows


def _phi(a, b, n):
    n11 = len(a & b)
    n10 = len(a - b)
    n01 = len(b - a)
    n00 = n - n11 - n10 - n01
    den = math.sqrt((n11 + n10) * (n01 + n00) * (n11 + n01) * (n10 + n00))
    return (n11 * n00 - n10 * n01) / den if den else 0.0


def _clusters(roles, files_with, jaccard):
    parent = {r: r for r in roles}

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for i, a in enumerate(roles):
        for b in roles[i + 1:]:
            u = len(files_with[a] | files_with[b])
            j = len(files_with[a] & files_with[b]) / u if u else 0
            if j >= jaccard:
                parent[find(a)] = find(b)
    groups = defaultdict(list)
    for r in roles:
        groups[find(r)].append(r)
    return list(groups.values())


def aggregate(features_path, ablation_path, out_dir, t_presence=0.6, t_necessity=0.5,
              min_cat_files=3, min_tested=5, jaccard_merge=0.9):
    os.makedirs(out_dir, exist_ok=True)
    feats = _load(features_path)
    abl = _load(ablation_path)
    by_ds = defaultdict(list)
    for r in feats:
        by_ds[r["dataset"]].append(r)
    if PRIMARY not in by_ds:
        raise SystemExit(f"No '{PRIMARY}' records in {features_path}; run features first.")
    prim = by_ds[PRIMARY]
    n_prim = len(prim)

    # presence per dataset
    presence, detectable = {}, {}
    for ds, rows in by_ds.items():
        keys = set(rows[0]["roles"].keys())
        detectable[ds] = keys
        presence[ds] = {k: sum(1 for r in rows if r["roles"].get(k, 0) > 0) / len(rows)
                        for k in keys}

    files_with = {role: {r["file"] for r in prim if r["roles"].get(role, 0) > 0}
                  for role in ROLES}

    # category coverage (primary)
    cats = defaultdict(list)
    for r in prim:
        cats[r["category"]].append(r)
    big = {c: rows for c, rows in cats.items() if len(rows) >= min_cat_files}
    coverage = {}
    for role in ROLES:
        hit = sum(1 for rows in big.values()
                  if sum(1 for r in rows if r["roles"].get(role, 0) > 0) / len(rows) >= 0.25)
        coverage[role] = hit / len(big) if big else float("nan")

    # ablation -> necessity
    baseline = defaultdict(int)
    per = defaultdict(lambda: {"valid": 0, "killed": 0})   # (file, role)
    for r in abl:
        if "baseline" in r:
            baseline[r["baseline"]] += 1
            continue
        if r["status"] in ("killed", "survived"):
            k = (r["file"], r["role"])
            per[k]["valid"] += 1
            per[k]["killed"] += r["status"] == "killed"
    nec, ntested, ncat = {}, {}, {}
    cat_of = {r["file"]: r["category"] for r in prim}
    for role in ROLES_WITH_ABLATION:
        items = [(f, v) for (f, ro), v in per.items() if ro == role and v["valid"] > 0]
        ntested[role] = len(items)
        nec[role] = (sum(1 for _, v in items if v["killed"] > 0) / len(items)) if items else float("nan")
        bycat = defaultdict(list)
        for f, v in items:
            bycat[cat_of.get(f, "?")].append(v["killed"] > 0)
        good = [sum(x) / len(x) >= 0.5 for x in bycat.values() if len(x) >= 3]
        ncat[role] = (sum(good) / len(good)) if good else float("nan")

    def classify(role, tp, tn):
        pres = presence[PRIMARY].get(role, 0)
        if pres < tp:
            return "SPECIALIZED"
        if role in ROLES_WITH_ABLATION:
            if ntested.get(role, 0) < min_tested or math.isnan(nec.get(role, float("nan"))):
                return "UNTESTED"
            return "INVARIANT_CANDIDATE" if nec[role] >= tn else "COMMON_OPTIONAL"
        return "PRESENCE_ONLY_CANDIDATE"

    def replicates(role, tp):
        others = [ds for ds in presence if ds != PRIMARY and role in detectable[ds]]
        if not others:
            return "n/a"
        return "yes" if all(presence[ds][role] >= tp - 0.2 for ds in others) else "no"

    table = []
    for role, desc in ROLES.items():
        table.append({
            "role": role, "description": desc,
            "presence_primary": round(presence[PRIMARY].get(role, 0), 3),
            **{f"presence_{ds}": (round(presence[ds][role], 3) if role in detectable[ds] else "")
               for ds in sorted(presence) if ds != PRIMARY},
            "category_coverage": round(coverage[role], 3) if not math.isnan(coverage[role]) else "",
            "necessity_rate": (round(nec[role], 3) if role in nec and not math.isnan(nec[role]) else ""),
            "files_tested": ntested.get(role, ""),
            "category_necessity": (round(ncat[role], 3) if role in ncat and not math.isnan(ncat[role]) else ""),
            "class": classify(role, t_presence, t_necessity),
            "replicates": replicates(role, t_presence),
        })
    with open(os.path.join(out_dir, "role_table.csv"), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(table[0].keys()))
        w.writeheader()
        w.writerows(table)

    cand = [t["role"] for t in table
            if t["class"] in ("INVARIANT_CANDIDATE", "PRESENCE_ONLY_CANDIDATE")]
    groups = _clusters(cand, files_with, jaccard_merge) if cand else []

    # complementary pairs: alternative realisations of one underlying invariant
    allroles = list(ROLES)
    comp = []
    for i, a in enumerate(allroles):
        for b in allroles[i + 1:]:
            pa, pb = presence[PRIMARY].get(a, 0), presence[PRIMARY].get(b, 0)
            if pa >= 0.9 or pb >= 0.9 or min(pa, pb) < 0.1:
                continue
            union = len(files_with[a] | files_with[b]) / n_prim
            if union >= 0.9:
                comp.append({"a": a, "b": b, "union": round(union, 3),
                             "phi": round(_phi(files_with[a], files_with[b], n_prim), 3)})
    comp.sort(key=lambda d: (-d["union"], d["phi"]))

    # sensitivity grid
    grid = []
    for tp in (0.4, 0.5, 0.6, 0.7, 0.8, 0.9):
        for tn in (0.25, 0.5, 0.75):
            cs = [r for r in ROLES if classify(r, tp, tn) in
                  ("INVARIANT_CANDIDATE", "PRESENCE_ONLY_CANDIDATE")]
            g = _clusters(cs, files_with, jaccard_merge) if cs else []
            grid.append({"t_presence": tp, "t_necessity": tn,
                         "candidates": len(cs), "independent_clusters": len(g)})

    summary = {
        "files_primary": n_prim, "categories_used": len(big),
        "baseline_outcomes": dict(baseline),
        "thresholds": {"presence": t_presence, "necessity": t_necessity,
                       "min_tested": min_tested, "jaccard_merge": jaccard_merge},
        "candidates": cand, "independent_groups": groups,
        "complementary_pairs": comp[:15], "sensitivity": grid,
    }
    with open(os.path.join(out_dir, "summary.json"), "w") as fh:
        json.dump(summary, fh, indent=2)

    L = ["# Invariant analysis report", "",
         f"Primary dataset: `{PRIMARY}` ({n_prim} files, {len(big)} categories with >= {min_cat_files} files).",
         f"Thresholds: presence >= {t_presence}, necessity >= {t_necessity}, merge Jaccard >= {jaccard_merge}.", ""]
    if baseline:
        L += ["Ablation baseline outcomes: " + ", ".join(f"{k}={v}" for k, v in sorted(baseline.items())), ""]
    L += [f"## Result: {len(cand)} candidate roles, {len(groups)} independent after merging", ""]
    for g in groups:
        L.append("- " + " + ".join(sorted(g)))
    L += ["", "## Full role table", "",
          "| role | presence | coverage | necessity | tested | class | replicates |",
          "|---|---|---|---|---|---|---|"]
    for t in sorted(table, key=lambda x: -x["presence_primary"]):
        L.append(f"| {t['role']} | {t['presence_primary']} | {t['category_coverage']} | "
                 f"{t['necessity_rate']} | {t['files_tested']} | {t['class']} | {t['replicates']} |")
    L += ["", "## Complementary pairs (alternative realisations of one invariant?)", ""]
    L += ([f"- {c['a']} / {c['b']}: union {c['union']}, phi {c['phi']}" for c in comp[:10]]
          or ["- none found"])
    L += ["", "## Sensitivity of the count to thresholds", "",
          "| presence | necessity | candidates | independent |", "|---|---|---|---|"]
    for g in grid:
        L.append(f"| {g['t_presence']} | {g['t_necessity']} | {g['candidates']} | {g['independent_clusters']} |")
    L += ["", "## Caveats", "",
          "- Roles are hypotheses from a fixed starting vocabulary; the analysis cannot discover roles outside it.",
          "- Necessity comes from mutation testing; equivalent mutants make it a lower bound.",
          "- Java results are regex-approximate and have no ablation.",
          "- Doctest-bearing files are a biased subset of the corpus."]
    with open(os.path.join(out_dir, "report.md"), "w") as fh:
        fh.write("\n".join(L) + "\n")
    print(f"[aggregate] {len(cand)} candidates, {len(groups)} independent -> {out_dir}/report.md")
