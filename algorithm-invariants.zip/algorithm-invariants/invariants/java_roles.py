"""APPROXIMATE role detector for Java (regex based, no ablation).

Only roles that can be recognised reliably from text are reported; everything
else is left out (None) so it is not mistaken for 'absent'.
"""
import re

DETECTABLE = [
    "INTAKE", "ITER_BOUNDED", "ITER_CONDITIONAL", "NESTED_ITERATION", "RECURSION",
    "BRANCH", "COMPARISON", "ACCUMULATE", "INDEXED_READ", "INDEXED_WRITE",
    "SWAP_EXCHANGE", "EARLY_EXIT", "SKIP", "OUTPUT_RETURN", "GUARD_VALIDATION",
    "AUX_STRUCTURE", "ARITHMETIC", "MODULAR_OR_BIT", "MUTATING_CALL",
]

UTILITY_FILES = {
    "StdOut", "StdIn", "StdDraw", "StdRandom", "StdStats", "StdAudio", "StdArrayIO",
    "In", "Out", "Draw", "DrawListener", "Picture", "GrayscalePicture", "BinaryIn",
    "BinaryOut", "BinaryStdIn", "BinaryStdOut", "Stopwatch", "StopwatchCPU",
    "Counter", "Date", "Transaction", "Accumulator", "VisualAccumulator",
    "Complex", "Vector", "Matrix", "SmallDigraph", "Interval1D", "Interval2D",
    "Point2D", "RectHV", "Insertion", "Knuth", "SET", "ST", "Bag", "Stack", "Queue",
}

_COMMENT = re.compile(r"//.*?$|/\*.*?\*/", re.S | re.M)
_STRING = re.compile(r'"(?:\\.|[^"\\])*"')
_METHOD = re.compile(
    r"(?:public|private|protected|static|final|\s)+[\w<>\[\],\s]+?\s+(\w+)\s*\(([^)]*)\)\s*(?:throws [\w.,\s]+)?\{")


def _clean(src):
    return _STRING.sub('""', _COMMENT.sub("", src))


def _body(src, start):
    depth, i = 0, start
    while i < len(src):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return src[start:i + 1]
        i += 1
    return src[start:]


def extract_roles(source):
    s = _clean(source)
    c = {r: 0 for r in DETECTABLE}
    methods = []
    for m in _METHOD.finditer(s):
        name, params = m.group(1), m.group(2).strip()
        if name in ("if", "for", "while", "switch", "catch", "return", "new"):
            continue
        body = _body(s, m.end() - 1)
        methods.append((name, params, body))
        if params:
            c["INTAKE"] += 1
        if re.search(r"\b%s\s*\(" % re.escape(name), body[1:]):
            c["RECURSION"] += 1
    c["ITER_BOUNDED"] = len(re.findall(r"\bfor\s*\(", s))
    c["ITER_CONDITIONAL"] = len(re.findall(r"\bwhile\s*\(", s))
    for m in re.finditer(r"\b(for|while)\s*\(", s):
        seg = _body(s, s.find("{", m.end())) if "{" in s[m.end():m.end() + 400] else ""
        if re.search(r"\b(for|while)\s*\(", seg[1:]):
            c["NESTED_ITERATION"] += 1
    c["BRANCH"] = len(re.findall(r"\bif\s*\(", s)) + len(re.findall(r"\bswitch\s*\(", s))
    c["COMPARISON"] = len(re.findall(r"compareTo|[<>]=?|==|!=", s))
    c["ACCUMULATE"] = len(re.findall(r"[+\-*/%]=|\+\+|--", s))
    c["INDEXED_WRITE"] = len(re.findall(r"\w\s*\[[^\]]*\]\s*=(?!=)", s))
    c["INDEXED_READ"] = len(re.findall(r"\w\s*\[[^\]]*\]", s)) - c["INDEXED_WRITE"]
    c["INDEXED_READ"] = max(c["INDEXED_READ"], 0)
    c["SWAP_EXCHANGE"] = len(re.findall(r"\b(exch|swap)\s*\(", s))
    c["EARLY_EXIT"] = len(re.findall(r"\bbreak\s*;", s))
    c["SKIP"] = len(re.findall(r"\bcontinue\s*;", s))
    c["OUTPUT_RETURN"] = len(re.findall(r"\breturn\s+[^;\s]", s))
    c["GUARD_VALIDATION"] = len(re.findall(r"\bthrow\s+new\b|\bassert\b", s))
    c["AUX_STRUCTURE"] = len(re.findall(r"\bnew\s+\w+(?:<[^>]*>)?\s*[\(\[]", s))
    c["ARITHMETIC"] = len(re.findall(r"[\w\)\]]\s*[+\-*/]\s*[\w\(]", s))
    c["MODULAR_OR_BIT"] = len(re.findall(r"%|<<|>>|[\w\)]\s*[&|^]\s*[\w\(]", s))
    c["MUTATING_CALL"] = len(re.findall(r"\.(add|push|enqueue|put|insert|remove|delete|pop|dequeue)\s*\(", s))
    return c
