"""Single-site ablation operators (mutation testing), one family per role.

An operator disables or perturbs exactly ONE occurrence of a role. If the
algorithm's tests then fail, that occurrence was necessary for it to work.
Caveat: some mutants are behaviour-equivalent (they survive without the role
being truly optional); the aggregate step reports rates, not certainties.
"""
import ast
import copy

from .roles import FUNC_TYPES, MUTATING_METHODS, self_call_name, recursive_names

_CMP_FLIP = {ast.Lt: ast.GtE, ast.Gt: ast.LtE, ast.LtE: ast.Gt,
             ast.GtE: ast.Lt, ast.Eq: ast.NotEq, ast.NotEq: ast.Eq}
_ARITH_SWAP = {ast.Add: ast.Sub, ast.Sub: ast.Add, ast.Mult: ast.Add,
               ast.Div: ast.Mult, ast.FloorDiv: ast.Mult, ast.Pow: ast.Mult}
_MODBIT_SWAP = {ast.Mod: ast.FloorDiv, ast.LShift: ast.RShift, ast.RShift: ast.LShift,
                ast.BitAnd: ast.BitOr, ast.BitOr: ast.BitAnd, ast.BitXor: ast.BitAnd}


class _Mutator(ast.NodeTransformer):
    def __init__(self, match, replace, k, rec):
        self.match, self.replace, self.k, self.rec = match, replace, k, rec
        self.i = -1
        self.applied = False
        self.fn_stack = []

    def visit(self, node):
        pushed = isinstance(node, FUNC_TYPES)
        if pushed:
            self.fn_stack.append(node.name)
        try:
            if self.match(node, self):
                self.i += 1
                if self.i == self.k:
                    self.applied = True
                    return self.replace(node)
            return self.generic_visit(node)
        finally:
            if pushed:
                self.fn_stack.pop()


def _body_or_pass(stmts):
    return list(stmts) if stmts else [ast.Pass()]


# ---- match / replace pairs -------------------------------------------------
def m_for(n, m): return isinstance(n, ast.For)
def r_for(n):
    new = copy.copy(n)
    call = ast.Call(func=ast.Name(id="list", ctx=ast.Load()), args=[n.iter], keywords=[])
    new.iter = ast.Subscript(value=call, ctx=ast.Load(),
                             slice=ast.Slice(lower=None, upper=ast.Constant(value=1), step=None))
    return new

def m_while(n, m): return isinstance(n, ast.While)
def r_while(n): return ast.If(test=n.test, body=n.body, orelse=[])

def m_if(n, m): return isinstance(n, ast.If)
def r_if_true(n): return _body_or_pass(n.body)
def r_if_false(n): return _body_or_pass(n.orelse)

def m_cmp(n, m): return (isinstance(n, ast.Compare) and len(n.ops) == 1
                         and type(n.ops[0]) in _CMP_FLIP)
def r_cmp(n):
    new = copy.copy(n)
    new.ops = [_CMP_FLIP[type(n.ops[0])]()]
    return new

def m_aug(n, m): return isinstance(n, ast.AugAssign)
def r_pass(n): return ast.Pass()

def m_idx_write(n, m): return (isinstance(n, ast.Assign) and len(n.targets) == 1
                               and isinstance(n.targets[0], ast.Subscript))

def m_swap(n, m):
    return (isinstance(n, ast.Assign) and len(n.targets) == 1
            and isinstance(n.targets[0], ast.Tuple) and isinstance(n.value, ast.Tuple)
            and len(n.targets[0].elts) == 2 == len(n.value.elts)
            and {ast.unparse(e) for e in n.targets[0].elts}
            == {ast.unparse(e) for e in n.value.elts})

def m_break(n, m): return isinstance(n, ast.Break)
def m_continue(n, m): return isinstance(n, ast.Continue)

def m_return(n, m): return isinstance(n, ast.Return) and n.value is not None
def r_return_none(n): return ast.Return(value=ast.Constant(value=None))

def m_guard(n, m): return isinstance(n, (ast.Raise, ast.Assert))

def m_rec_call(n, m):
    return isinstance(n, ast.Call) and self_call_name(n.func) in m.rec
def r_none(n): return ast.Constant(value=None)

def m_base_case(n, m):
    return (isinstance(n, ast.If) and m.fn_stack and m.fn_stack[-1] in m.rec
            and any(isinstance(s, ast.Return) for s in n.body))

def m_state_init(n, m):
    return (isinstance(n, ast.Assign) and len(n.targets) == 1
            and isinstance(n.targets[0], ast.Name) and bool(m.fn_stack)
            and isinstance(n.value, ast.Constant)
            and isinstance(n.value.value, (int, float))
            and not isinstance(n.value.value, bool))
def r_state_init(n):
    new = copy.copy(n)
    new.value = ast.Constant(value=n.value.value + 1)
    return new

def m_mutcall(n, m):
    return (isinstance(n, ast.Expr) and isinstance(n.value, ast.Call)
            and isinstance(n.value.func, ast.Attribute)
            and n.value.func.attr in MUTATING_METHODS)

def m_arith(n, m): return isinstance(n, ast.BinOp) and type(n.op) in _ARITH_SWAP
def r_arith(n):
    new = copy.copy(n)
    new.op = _ARITH_SWAP[type(n.op)]()
    return new

def m_modbit(n, m): return isinstance(n, ast.BinOp) and type(n.op) in _MODBIT_SWAP
def r_modbit(n):
    new = copy.copy(n)
    new.op = _MODBIT_SWAP[type(n.op)]()
    return new

def m_slice(n, m): return isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Slice)
def r_slice(n):
    new = copy.copy(n)
    new.slice = ast.Slice(lower=None, upper=None, step=None)
    return new


# operator name -> (role, match, replace)
OPS = {
    "ITER_BOUNDED/first_only": ("ITER_BOUNDED", m_for, r_for),
    "ITER_CONDITIONAL/single_pass": ("ITER_CONDITIONAL", m_while, r_while),
    "BRANCH/always_true": ("BRANCH", m_if, r_if_true),
    "BRANCH/always_false": ("BRANCH", m_if, r_if_false),
    "COMPARISON/flip": ("COMPARISON", m_cmp, r_cmp),
    "ACCUMULATE/drop": ("ACCUMULATE", m_aug, r_pass),
    "INDEXED_WRITE/drop": ("INDEXED_WRITE", m_idx_write, r_pass),
    "SWAP_EXCHANGE/drop": ("SWAP_EXCHANGE", m_swap, r_pass),
    "EARLY_EXIT/drop": ("EARLY_EXIT", m_break, r_pass),
    "SKIP/drop": ("SKIP", m_continue, r_pass),
    "OUTPUT_RETURN/none": ("OUTPUT_RETURN", m_return, r_return_none),
    "GUARD_VALIDATION/drop": ("GUARD_VALIDATION", m_guard, r_pass),
    "RECURSION/cut_call": ("RECURSION", m_rec_call, r_none),
    "BASE_CASE/drop": ("BASE_CASE", m_base_case, lambda n: _body_or_pass(n.orelse)),
    "STATE_INIT/perturb": ("STATE_INIT", m_state_init, r_state_init),
    "MUTATING_CALL/drop": ("MUTATING_CALL", m_mutcall, r_pass),
    "ARITHMETIC/swap": ("ARITHMETIC", m_arith, r_arith),
    "MODULAR_OR_BIT/swap": ("MODULAR_OR_BIT", m_modbit, r_modbit),
    "SLICE_PARTITION/full": ("SLICE_PARTITION", m_slice, r_slice),
}
ROLES_WITH_ABLATION = sorted({v[0] for v in OPS.values()})


def count_sites(tree, opname, rec):
    _, match, replace = OPS[opname]
    m = _Mutator(match, replace, -1, rec)
    m.visit(copy.deepcopy(tree))
    return m.i + 1


def make_mutant(tree, opname, k, rec):
    """Return mutated source, or None if the mutant is not valid Python."""
    _, match, replace = OPS[opname]
    t = copy.deepcopy(tree)
    m = _Mutator(match, replace, k, rec)
    t = m.visit(t)
    if not m.applied:
        return None
    try:
        ast.fix_missing_locations(t)
        src = ast.unparse(t)
        compile(src, "<mutant>", "exec")
    except Exception:
        return None
    return src
