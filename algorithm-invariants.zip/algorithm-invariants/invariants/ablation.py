"""Run doctest-based ablation (mutation testing) over a Python algorithm repo."""
import ast
import json
import os
import random
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed

from .mutate import OPS, count_sites, make_mutant
from .roles import recursive_names

DEFAULT_EXCLUDE = {
    "web_programming", "scripts", "project_euler", "docs", "tests", "test",
    "computer_vision", "digital_image_processing", "audio_filters",
    "machine_learning", "neural_network", "quantum", "file_transfer",
    "graphics", "physics", "electronics", "financial", "fractals",
    "blockchain", "dynamic_programming_unused", ".git", ".github", "venv",
}


def _limits():
    try:
        import resource
        resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
        resource.setrlimit(resource.RLIMIT_CPU, (60, 60))
    except Exception:
        pass


def run_doctest(path, repo_root, timeout):
    env = os.environ.copy()
    env["PYTHONPATH"] = repo_root + os.pathsep + env.get("PYTHONPATH", "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["MPLBACKEND"] = "Agg"
    kw = {"preexec_fn": _limits} if os.name == "posix" else {}
    try:
        p = subprocess.run([sys.executable, "-m", "doctest", path],
                           cwd=os.path.dirname(path), env=env,
                           capture_output=True, timeout=timeout, **kw)
        return "pass" if p.returncode == 0 else "fail"
    except subprocess.TimeoutExpired:
        return "timeout"
    except Exception:
        return "error"


def list_candidates(repo_root, exclude=DEFAULT_EXCLUDE):
    out = []
    for dp, dns, fns in os.walk(repo_root):
        rel_dir = os.path.relpath(dp, repo_root)
        top = rel_dir.split(os.sep)[0]
        if top in exclude:
            dns[:] = []
            continue
        dns[:] = [d for d in dns if d not in exclude and not d.startswith(".")]
        if rel_dir == ".":
            continue  # skip top-level misc files
        for f in fns:
            if f.endswith(".py") and f != "__init__.py":
                out.append(os.path.join(rel_dir, f))
    return sorted(out)


def ablate_file(repo_root, rel, max_sites, timeout, seed):
    cat = rel.split(os.sep)[0]
    try:
        with open(os.path.join(repo_root, rel), encoding="utf-8") as fh:
            src = fh.read()
    except Exception:
        return [{"file": rel, "category": cat, "baseline": "unreadable"}]
    if ">>>" not in src or len(src) > 80_000:
        return [{"file": rel, "category": cat, "baseline": "no_doctests"}]
    try:
        tree = ast.parse(src)
    except Exception:
        return [{"file": rel, "category": cat, "baseline": "unparsable"}]
    rec = recursive_names(tree)
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, os.path.basename(rel))
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(src)
        b = run_doctest(path, repo_root, timeout)
        if b != "pass":
            return [{"file": rel, "category": cat, "baseline": b}]
        recs = [{"file": rel, "category": cat, "baseline": "pass"}]
        rng = random.Random(f"{seed}:{rel}")
        for opname, (role, _, _) in OPS.items():
            n = count_sites(tree, opname, rec)
            if n == 0:
                continue
            sites = list(range(n))
            rng.shuffle(sites)
            for k in sorted(sites[:max_sites]):
                msrc = make_mutant(tree, opname, k, rec)
                if msrc is None:
                    status = "invalid"
                else:
                    with open(path, "w", encoding="utf-8") as fh:
                        fh.write(msrc)
                    st = run_doctest(path, repo_root, timeout)
                    status = {"pass": "survived", "fail": "killed",
                              "timeout": "killed", "error": "invalid"}[st]
                recs.append({"file": rel, "category": cat, "role": role,
                             "op": opname, "site": k, "of": n, "status": status})
        return recs


def run(repo_root, out_path, max_sites=3, timeout=15, workers=4, limit=None,
        seed=0, resume=True):
    repo_root = os.path.abspath(repo_root)
    files = list_candidates(repo_root)
    done = set()
    if resume and os.path.exists(out_path):
        with open(out_path) as fh:
            for line in fh:
                try:
                    done.add(json.loads(line)["file"])
                except Exception:
                    pass
    if limit:
        random.Random(seed).shuffle(files)
        files = sorted(files[:limit])
    todo = [f for f in files if f not in done]
    print(f"[ablation] {len(files)} candidate files, {len(todo)} to do", flush=True)
    with open(out_path, "a") as out, ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(ablate_file, repo_root, f, max_sites, timeout, seed): f for f in todo}
        for i, fut in enumerate(as_completed(futs), 1):
            try:
                for r in fut.result():
                    out.write(json.dumps(r) + "\n")
                out.flush()
            except Exception as e:  # keep going
                print("  error on", futs[fut], e, flush=True)
            if i % 25 == 0:
                print(f"  {i}/{len(todo)} files", flush=True)
    print("[ablation] done ->", out_path)
