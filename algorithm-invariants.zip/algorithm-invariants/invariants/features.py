"""Static role extraction over the three datasets -> features.jsonl"""
import json
import os

from . import roles as pyroles
from . import java_roles
from .ablation import DEFAULT_EXCLUDE


def _py_files_algorithms(root):
    for dp, dns, fns in os.walk(root):
        rel_dir = os.path.relpath(dp, root)
        top = rel_dir.split(os.sep)[0]
        if top in DEFAULT_EXCLUDE:
            dns[:] = []
            continue
        dns[:] = [d for d in dns if d not in DEFAULT_EXCLUDE and not d.startswith(".")]
        if rel_dir == ".":
            continue
        for f in fns:
            if f.endswith(".py") and f != "__init__.py":
                yield top, os.path.join(dp, f), os.path.join(rel_dir, f)


def _py_files_rosetta(root):
    task_dir = os.path.join(root, "Task")
    if not os.path.isdir(task_dir):
        return
    for task in sorted(os.listdir(task_dir)):
        d = os.path.join(task_dir, task, "Python")
        if os.path.isdir(d):
            for f in sorted(os.listdir(d)):
                if f.endswith(".py"):
                    yield task, os.path.join(d, f), os.path.join(task, f)


def _java_files(root):
    for dp, _, fns in os.walk(root):
        for f in fns:
            if f.endswith(".java") and f[:-5] not in java_roles.UTILITY_FILES:
                yield f[:-5], os.path.join(dp, f), f


def run(out_path, algorithms_py=None, rosetta=None, algs4=None):
    n = {"ok": 0, "skipped": 0}
    with open(out_path, "w") as out:
        def emit(dataset, cat, path, rel, extractor):
            try:
                with open(path, encoding="utf-8", errors="replace") as fh:
                    src = fh.read()
            except Exception:
                n["skipped"] += 1
                return
            r = extractor(src)
            if r is None:
                n["skipped"] += 1
                return
            n["ok"] += 1
            out.write(json.dumps({"dataset": dataset, "category": cat,
                                  "file": rel, "roles": r}) + "\n")

        if algorithms_py:
            for cat, p, rel in _py_files_algorithms(algorithms_py):
                emit("algorithms_py", cat, p, rel, pyroles.extract_roles)
        if rosetta:
            for cat, p, rel in _py_files_rosetta(rosetta):
                emit("rosetta_py", cat, p, rel, pyroles.extract_roles)
        if algs4:
            for cat, p, rel in _java_files(algs4):
                emit("algs4_java", cat, p, rel, java_roles.extract_roles)
    print(f"[features] parsed {n['ok']} files, skipped {n['skipped']} -> {out_path}")
