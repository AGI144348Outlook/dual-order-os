"""Candidate structural roles and a static detector for Python source.

These roles are HYPOTHESES, not a fixed answer. The analysis decides which
ones survive. Nothing here assumes a target count.
"""
import ast

ROLES = {
    "INTAKE": "function takes input parameters",
    "STATE_INIT": "working state set to a literal before the main loop/recursion",
    "ITER_BOUNDED": "for-loop (repetition over a known collection)",
    "ITER_CONDITIONAL": "while-loop (repetition until a condition changes)",
    "NESTED_ITERATION": "a loop inside a loop",
    "RECURSION": "a function calls itself",
    "BASE_CASE": "recursive function has a returning branch (stopping condition)",
    "BRANCH": "if/else decision",
    "COMPARISON": "comparison of two values",
    "ACCUMULATE": "augmented assignment (+=, -=, ...) building up a value",
    "INDEXED_READ": "read from a position in a sequence/mapping",
    "INDEXED_WRITE": "write to a position in a sequence/mapping",
    "SWAP_EXCHANGE": "two positions/values exchanged",
    "SLICE_PARTITION": "sequence split by slicing",
    "EARLY_EXIT": "break out of a loop",
    "SKIP": "continue to next iteration",
    "OUTPUT_RETURN": "return of a value",
    "GUARD_VALIDATION": "raise/assert guarding inputs or invariants",
    "AUX_STRUCTURE": "auxiliary container created (list/dict/set/deque/...)",
    "MEMO_TABLE": "cache/memo/dp table or cache decorator",
    "COMPOSITION_CALL": "calls another function defined in the same module",
    "ARITHMETIC": "arithmetic (+ - * / // **)",
    "MODULAR_OR_BIT": "modulo or bit-level operation",
    "COMPREHENSION": "comprehension or generator expression",
    "ORDERING_PRIMITIVE": "sorted/min/max/heap/bisect style ordering call",
    "MUTATING_CALL": "in-place mutation call (append, pop, add, ...)",
}

MUTATING_METHODS = {
    "append", "appendleft", "pop", "popleft", "remove", "insert", "extend",
    "add", "update", "discard", "clear", "push", "put", "enqueue", "dequeue",
}
CONTAINER_CALLS = {"list", "dict", "set", "deque", "defaultdict", "Counter", "OrderedDict"}
ORDERING_CALLS = {
    "sorted", "sort", "heappush", "heappop", "heapify", "min", "max",
    "nlargest", "nsmallest", "bisect", "bisect_left", "bisect_right", "insort",
}
MEMO_NAMES = {"memo", "cache", "dp", "table", "lookup", "memoized"}
ARITH = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Pow)
MODBIT = (ast.Mod, ast.LShift, ast.RShift, ast.BitAnd, ast.BitOr, ast.BitXor)
FUNC_TYPES = (ast.FunctionDef, ast.AsyncFunctionDef)


def self_call_name(func):
    """Name of a call target: plain name, or self.name / cls.name. Else None."""
    if isinstance(func, ast.Name):
        return func.id
    if (isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name)
            and func.value.id in ("self", "cls")):
        return func.attr
    return None


def any_call_name(func):
    if isinstance(func, ast.Name):
        return func.id
    if isinstance(func, ast.Attribute):
        return func.attr
    return None


def function_defs(tree):
    return [n for n in ast.walk(tree) if isinstance(n, FUNC_TYPES)]


def recursive_names(tree):
    out = set()
    for fn in function_defs(tree):
        for n in ast.walk(fn):
            if isinstance(n, ast.Call) and self_call_name(n.func) == fn.name:
                out.add(fn.name)
                break
    return out


def extract_roles(source):
    """Return {role: count} for one Python source string, or None if unparsable."""
    try:
        tree = ast.parse(source)
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        return None
    c = {r: 0 for r in ROLES}
    fns = function_defs(tree)
    names = {f.name for f in fns}
    rec = recursive_names(tree)
    c["RECURSION"] = len(rec)

    for fn in fns:
        a = fn.args
        params = [x.arg for x in (a.posonlyargs + a.args + a.kwonlyargs)
                  if x.arg not in ("self", "cls")]
        if params or a.vararg or a.kwarg:
            c["INTAKE"] += 1
        has_loop = any(isinstance(n, (ast.For, ast.While)) for n in ast.walk(fn))
        if has_loop or fn.name in rec:
            for stmt in fn.body:
                if isinstance(stmt, (ast.For, ast.While)):
                    break
                if (isinstance(stmt, ast.Assign) and len(stmt.targets) == 1
                        and isinstance(stmt.targets[0], ast.Name)
                        and isinstance(stmt.value, (ast.Constant, ast.List, ast.Dict,
                                                    ast.Set, ast.Tuple))):
                    c["STATE_INIT"] += 1
        for n in ast.walk(fn):
            if isinstance(n, ast.Call):
                nm = self_call_name(n.func)
                if nm in names and nm != fn.name:
                    c["COMPOSITION_CALL"] += 1
        if fn.name in rec:
            for n in ast.walk(fn):
                if isinstance(n, ast.If) and any(isinstance(s, ast.Return) for s in n.body):
                    c["BASE_CASE"] += 1
        for d in fn.decorator_list:
            dn = ast.unparse(d).lower()
            if "cache" in dn or "memo" in dn:
                c["MEMO_TABLE"] += 1

    for n in ast.walk(tree):
        if isinstance(n, ast.For):
            c["ITER_BOUNDED"] += 1
        elif isinstance(n, ast.While):
            c["ITER_CONDITIONAL"] += 1
        if isinstance(n, (ast.For, ast.While)):
            if any(s is not n and isinstance(s, (ast.For, ast.While)) for s in ast.walk(n)):
                c["NESTED_ITERATION"] += 1
        if isinstance(n, ast.If):
            c["BRANCH"] += 1
        elif isinstance(n, ast.Compare):
            c["COMPARISON"] += 1
        elif isinstance(n, ast.AugAssign):
            c["ACCUMULATE"] += 1
        elif isinstance(n, ast.Subscript):
            if isinstance(n.slice, ast.Slice):
                pass
            elif isinstance(n.ctx, ast.Store):
                c["INDEXED_WRITE"] += 1
            else:
                c["INDEXED_READ"] += 1
        elif isinstance(n, ast.Slice):
            c["SLICE_PARTITION"] += 1
        elif isinstance(n, ast.Assign):
            if (len(n.targets) == 1 and isinstance(n.targets[0], ast.Tuple)
                    and isinstance(n.value, ast.Tuple)
                    and len(n.targets[0].elts) == 2 == len(n.value.elts)):
                lhs = {ast.unparse(e) for e in n.targets[0].elts}
                rhs = {ast.unparse(e) for e in n.value.elts}
                if lhs == rhs:
                    c["SWAP_EXCHANGE"] += 1
            for t in n.targets:
                if isinstance(t, ast.Name) and t.id.lower() in MEMO_NAMES:
                    c["MEMO_TABLE"] += 1
        elif isinstance(n, ast.Break):
            c["EARLY_EXIT"] += 1
        elif isinstance(n, ast.Continue):
            c["SKIP"] += 1
        elif isinstance(n, ast.Return) and n.value is not None:
            c["OUTPUT_RETURN"] += 1
        elif isinstance(n, (ast.Raise, ast.Assert)):
            c["GUARD_VALIDATION"] += 1
        elif isinstance(n, ast.BinOp):
            if isinstance(n.op, ARITH):
                c["ARITHMETIC"] += 1
            elif isinstance(n.op, MODBIT):
                c["MODULAR_OR_BIT"] += 1
        elif isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            c["COMPREHENSION"] += 1
        elif isinstance(n, ast.Call):
            nm = any_call_name(n.func)
            if nm in ORDERING_CALLS:
                c["ORDERING_PRIMITIVE"] += 1
            if nm in CONTAINER_CALLS and not n.args and not n.keywords:
                c["AUX_STRUCTURE"] += 1
        elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call):
            f = n.value.func
            if isinstance(f, ast.Attribute) and f.attr in MUTATING_METHODS:
                c["MUTATING_CALL"] += 1
        if isinstance(n, ast.List) and not n.elts or isinstance(n, ast.Dict) and not n.keys \
                or isinstance(n, ast.Set) and not n.elts:
            c["AUX_STRUCTURE"] += 1
    return c
