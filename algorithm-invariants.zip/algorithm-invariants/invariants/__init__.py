"""algorithm-invariants: look for structural roles that every working algorithm needs."""
