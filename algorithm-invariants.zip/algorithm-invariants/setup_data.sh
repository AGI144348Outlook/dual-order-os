#!/usr/bin/env bash
# Fetch the three datasets (shallow). Needs git and network access to github.com.
set -euo pipefail
mkdir -p data && cd data
[ -d TheAlgorithms-Python ] || git clone --depth 1 https://github.com/TheAlgorithms/Python.git TheAlgorithms-Python
[ -d algs4 ] || git clone --depth 1 https://github.com/kevin-wayne/algs4.git algs4
if [ ! -d RosettaCodeData ]; then
  git clone --depth 1 --filter=blob:none --sparse https://github.com/acmeism/RosettaCodeData.git
  (cd RosettaCodeData && git sparse-checkout set --no-cone '/Task/*/Python/' '/Task/*/00-TASK.txt')
fi
echo "data ready:"; du -sh */
